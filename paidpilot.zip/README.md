# PaidPilot MVP

A responsive invoice and customer tracking web app for small businesses, built with Next.js, TypeScript, and Supabase Auth/Postgres. It works in mobile and desktop browsers.

## Current MVP features
- Email/password account creation and sign-in using Supabase Auth
- Cookie-based auth session handling
- Customer records (name, optional email)
- Invoice records (number, customer, description, amount in CAD, due date)
- Invoice statuses: draft, sent, paid, overdue
- Dashboard totals for outstanding, paid, overdue, and customers
- Searchable invoice/customer views
- Row Level Security policies for tenant data isolation
- Responsive layouts for phones and computers

## Not included yet
- Automatic email reminders or sending invoice emails
- PDF invoice generation
- Payment processing or Stripe subscriptions
- Password reset and email-change UX
- Team seats/roles, audit logs, automated overdue status updates
- Formal security review, accessibility review, and production monitoring

This is an MVP starter, not yet ready for storing sensitive real customer data at scale. Test with sample data first.

## Step 1 — Supabase setup
You already created a Supabase project and ran the initial SQL that created `customers` and `invoices`.

1. Open the Supabase project dashboard.
2. Open **Project Settings → API** (or **Connect**, depending on the dashboard version).
3. Copy the **Project URL**.
4. Copy the **publishable/anon public key**. Never use a `service_role` or secret key in the browser.
5. Keep both values for the environment setup step below.

The app expects the two existing tables created by the earlier starter SQL. This repo's `supabase/migrations/001_paidpilot.sql` documents the full schema and stronger invoice/customer ownership policy. If applying its stronger policy, open SQL Editor and run only the policy replacement section (the `drop policy if exists` and `create policy` statements) rather than rerunning the table creation statements. The stronger invoice policy prevents attaching another user's customer ID to an invoice.

## Step 2 — Deploy from a phone with minimal coding
Replit or another online IDE can import this project ZIP. You can also use a computer later; the same project works either way.

1. Download/unzip the `paidpilot.zip` file.
2. In Replit, create a new web app/project and upload/import the project files if that workflow is available in your account. Online IDE menus change, so choose a Next.js/Node.js project if asked.
3. Add these environment variables in the project's Secrets/Environment Variables area:
   - `NEXT_PUBLIC_SUPABASE_URL` = your Supabase Project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = the public publishable/anon key
4. Install dependencies with `npm install`.
5. Start preview with `npm run dev` (or the platform's Run button).
6. If the build fails because of an environment or platform version issue, share the error text/screenshot (hide keys).

Do not paste secrets into chat, source files, or screenshots. The `NEXT_PUBLIC_` values are exposed to the browser by design, so only use the Supabase publishable/anon key. Row Level Security must stay enabled.

## Step 3 — Configure authentication
In Supabase:
1. Open **Authentication → URL Configuration**.
2. Set the Site URL to the deployed web app URL once you have it.
3. Add the preview/deployment URL to Redirect URLs if needed.
4. For early testing, email confirmation may be enabled. If signup says to check email, confirm the email then sign in.
5. Test signup/signin, add one sample customer, create an invoice, refresh the page, and confirm records persist.

## Step 4 — Publish
Deploy to Vercel or a supported hosting provider. Add the same two environment variables in the host's project settings. Use the deployment's real HTTPS URL as the Supabase Site URL and allowed redirect URL. Open that URL on both phone and computer.

## Security notes
- Never expose Supabase `service_role` / secret keys in browser code or chat.
- Keep Row Level Security enabled on every user-data table.
- The app uses authenticated browser operations plus RLS; the app's user_id value is not a substitute for database policies.
- Don't enter real customer information until you've tested cross-account isolation and reviewed security.
- Use unique invoice numbers per user.
- A production launch should add automated tests, rate limiting/abuse protection, monitoring, privacy terms, and a reviewed backup plan.

## Development
```bash
npm install
cp .env.example .env.local
# fill .env.local with your Supabase URL and public key
npm run dev
```

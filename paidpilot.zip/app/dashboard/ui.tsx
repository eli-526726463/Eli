"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Plane, LayoutDashboard, Users, FileText, Plus, Search, Bell, LogOut, Menu, X, ChevronDown, ArrowUpRight, CircleDollarSign, Clock3, CheckCircle2, AlertCircle, MoreHorizontal, LoaderCircle } from "lucide-react";

type Customer = { id:string; name:string; email:string|null };
type Invoice = { id:string; customer_id:string; invoice_number:string; description:string|null; amount:number; due_date:string|null; status:"draft"|"sent"|"paid"|"overdue"; created_at:string };
const money = (n:number) => new Intl.NumberFormat("en-CA",{style:"currency",currency:"CAD"}).format(n);
const prettyDate = (s:string|null) => s ? new Date(s+"T12:00:00").toLocaleDateString("en-CA",{month:"short",day:"numeric",year:"numeric"}) : "No due date";

export default function Dashboard({email}:{email:string}) {
  const supabase = useMemo(()=>createClient(),[]);
  const router = useRouter();
  const [customers,setCustomers]=useState<Customer[]>([]);
  const [invoices,setInvoices]=useState<Invoice[]>([]);
  const [tab,setTab]=useState<"overview"|"invoices"|"customers">("overview");
  const [search,setSearch]=useState("");
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState("");
  const [modal,setModal]=useState<"customer"|"invoice"|null>(null);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState("");
  const [menuOpen,setMenuOpen]=useState(false);
  const [customerName,setCustomerName]=useState(""); const [customerEmail,setCustomerEmail]=useState("");
  const [invoiceCustomer,setInvoiceCustomer]=useState(""); const [invoiceNumber,setInvoiceNumber]=useState("");
  const [invoiceDescription,setInvoiceDescription]=useState(""); const [invoiceAmount,setInvoiceAmount]=useState("");
  const [invoiceDue,setInvoiceDue]=useState(""); const [invoiceStatus,setInvoiceStatus]=useState<Invoice["status"]>("sent");

  async function load() {
    setLoading(true);setError("");
    const [c,i]=await Promise.all([
      supabase.from("customers").select("id,name,email").order("created_at",{ascending:false}),
      supabase.from("invoices").select("id,customer_id,invoice_number,description,amount,due_date,status,created_at").order("created_at",{ascending:false})
    ]);
    if(c.error || i.error) setError(c.error?.message || i.error?.message || "Could not load records.");
    else {setCustomers(c.data??[]);setInvoices(i.data??[]);}
    setLoading(false);
  }
  useEffect(()=>{load();},[]);
  async function signOut(){await supabase.auth.signOut();router.push("/login");router.refresh();}
  async function addCustomer(e:React.FormEvent){
    e.preventDefault();setBusy(true);setError("");setNotice("");
    const {data:{user}}=await supabase.auth.getUser();
    if(!user){setError("Your session expired. Please sign in again.");setBusy(false);return;}
    const {error}=await supabase.from("customers").insert({user_id:user.id,name:customerName.trim(),email:customerEmail.trim()||null});
    setBusy(false);
    if(error){setError(error.message);return;}
    setCustomerName("");setCustomerEmail("");setModal(null);setNotice("Customer saved.");await load();
  }
  async function addInvoice(e:React.FormEvent){
    e.preventDefault();setBusy(true);setError("");setNotice("");
    const {data:{user}}=await supabase.auth.getUser();
    if(!user){setError("Your session expired. Please sign in again.");setBusy(false);return;}
    const customer=customers.find(c=>c.id===invoiceCustomer);
    if(!customer){setError("Choose a customer first.");setBusy(false);return;}
    const {error}=await supabase.from("invoices").insert({user_id:user.id,customer_id:invoiceCustomer,invoice_number:invoiceNumber.trim(),description:invoiceDescription.trim()||null,amount:Number(invoiceAmount),due_date:invoiceDue||null,status:invoiceStatus});
    setBusy(false);
    if(error){setError(error.message);return;}
    setInvoiceNumber("");setInvoiceDescription("");setInvoiceAmount("");setInvoiceDue("");setModal(null);setNotice("Invoice saved.");await load();
  }
  async function changeStatus(inv:Invoice,status:Invoice["status"]){
    const {error}=await supabase.from("invoices").update({status}).eq("id",inv.id);
    if(error)setError(error.message);else {setNotice(`Invoice ${inv.invoice_number} marked ${status}.`);await load();}
  }
  const customerMap=new Map(customers.map(c=>[c.id,c]));
  const filteredInvoices=invoices.filter(i=>[i.invoice_number,i.description??"",customerMap.get(i.customer_id)?.name??"",i.status].join(" ").toLowerCase().includes(search.toLowerCase()));
  const filteredCustomers=customers.filter(c=>[c.name,c.email??""].join(" ").toLowerCase().includes(search.toLowerCase()));
  const outstanding=invoices.filter(i=>i.status==="sent"||i.status==="overdue").reduce((s,i)=>s+Number(i.amount),0);
  const paid=invoices.filter(i=>i.status==="paid").reduce((s,i)=>s+Number(i.amount),0);
  const overdue=invoices.filter(i=>i.status==="overdue"||(i.status==="sent"&&i.due_date&&i.due_date<new Date().toISOString().slice(0,10)));
  function go(t:"overview"|"invoices"|"customers"){setTab(t);setSearch("");setMenuOpen(false);}
  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen?"open":""}`}><a className="brand" href="/dashboard"><span className="brand-mark"><Plane size={19}/></span> paidpilot</a>
      <div className="workspace"><div className="workspace-icon">P</div><div><b>My workspace</b><span>Free workspace</span></div><ChevronDown size={15}/></div>
      <span className="nav-label">WORKSPACE</span><nav>
        <button className={tab==="overview"?"nav-item active":"nav-item"} onClick={()=>go("overview")}><LayoutDashboard size={18}/> Overview</button>
        <button className={tab==="invoices"?"nav-item active":"nav-item"} onClick={()=>go("invoices")}><FileText size={18}/> Invoices <span className="nav-count">{invoices.length}</span></button>
        <button className={tab==="customers"?"nav-item active":"nav-item"} onClick={()=>go("customers")}><Users size={18}/> Customers <span className="nav-count">{customers.length}</span></button>
      </nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon">✦</div><b>Keep cash flow clear</b><p>Stay on top of every invoice, all in one place.</p></div><div className="profile"><div className="avatar">{(email[0]||"U").toUpperCase()}</div><div className="profile-text"><b>{email}</b><span>Account owner</span></div><button className="icon-button" aria-label="Sign out" onClick={signOut}><LogOut size={17}/></button></div></div>
    </aside>
    {menuOpen&&<button className="mobile-scrim" aria-label="Close menu" onClick={()=>setMenuOpen(false)} />}
    <main className="main"><header className="topbar"><button className="mobile-menu icon-button" aria-label="Open menu" onClick={()=>setMenuOpen(!menuOpen)}>{menuOpen?<X/>:<Menu/>}</button><div className="breadcrumb">Workspace <span>/</span> <b>{tab==="overview"?"Overview":tab==="invoices"?"Invoices":"Customers"}</b></div><div className="top-actions"><span className="status-pill"><span/> All changes saved</span><div className="avatar small">{(email[0]||"U").toUpperCase()}</div></div></header>
      <div className="content"><div className="page-heading"><div><span className="eyebrow">YOUR BUSINESS AT A GLANCE</span><h1>{tab==="overview"?"Good to see you.":tab==="invoices"?"Invoices":"Customers"}</h1><p>{tab==="overview"?"Here’s what’s happening with your cash flow.":tab==="invoices"?"Create, track, and update your invoices.":"Keep your customer details organized."}</p></div><div className="heading-actions"><button className="secondary" onClick={()=>setModal("customer")}><Plus size={17}/> Add customer</button><button className="primary" onClick={()=>{if(customers.length===0){setError("Add a customer first, then create an invoice.");return;}setInvoiceCustomer(customers[0].id);setModal("invoice");}}><Plus size={17}/> New invoice</button></div></div>
      {(error||notice)&&<div className={error?"notice error":"notice success"}>{error||notice}<button onClick={()=>{setError("");setNotice("");}} aria-label="Dismiss">×</button></div>}
      {tab==="overview"&&<><div className="stat-grid">
        <div className="stat-card"><div className="stat-top"><span>Total outstanding</span><span className="stat-icon orange"><CircleDollarSign size={19}/></span></div><strong>{money(outstanding)}</strong><small>Sent and overdue invoices</small><div className="stat-foot"><ArrowUpRight size={15}/> Keep follow-ups moving</div></div>
        <div className="stat-card"><div className="stat-top"><span>Collected</span><span className="stat-icon green"><CheckCircle2 size={19}/></span></div><strong>{money(paid)}</strong><small>Marked as paid</small><div className="stat-foot green-text"><CheckCircle2 size={15}/> Great progress</div></div>
        <div className="stat-card"><div className="stat-top"><span>Overdue</span><span className="stat-icon red"><AlertCircle size={19}/></span></div><strong>{overdue.length}</strong><small>Invoices need attention</small><div className="stat-foot red-text"><Clock3 size={15}/> Review due dates</div></div>
        <div className="stat-card"><div className="stat-top"><span>Customers</span><span className="stat-icon blue"><Users size={19}/></span></div><strong>{customers.length}</strong><small>In your workspace</small><div className="stat-foot"><Users size={15}/> Relationships matter</div></div>
      </div><div className="section-card"><div className="section-head"><div><h2>Recent invoices</h2><p>Your latest billing activity</p></div><button className="text-button" onClick={()=>go("invoices")}>View all <ArrowUpRight size={15}/></button></div><InvoiceTable invoices={invoices.slice(0,5)} customerMap={customerMap} changeStatus={changeStatus} loading={loading}/></div><div className="bottom-grid"><div className="section-card"><div className="section-head"><div><h2>Customers</h2><p>Your client list</p></div><button className="text-button" onClick={()=>go("customers")}>View all <ArrowUpRight size={15}/></button></div>{customers.slice(0,4).map(c=><div className="customer-row" key={c.id}><div className="avatar">{c.name[0]?.toUpperCase()}</div><div className="customer-info"><b>{c.name}</b><span>{c.email||"No email added"}</span></div><span className="customer-total">{invoices.filter(i=>i.customer_id===c.id).length} invoices</span></div>)}{!loading&&!customers.length&&<Empty title="No customers yet" detail="Add your first customer to get started."/>}</div><div className="tip-card"><span className="tip-spark">✦</span><span className="eyebrow">A GOOD HABIT</span><h2>Make getting paid feel simpler.</h2><p>Add each customer once, then attach their invoices so you can see what’s paid and what still needs a nudge.</p><button className="secondary" onClick={()=>setModal("customer")}>Add your first customer <ArrowUpRight size={16}/></button></div></div></>}
      {tab==="invoices"&&<div className="section-card"><div className="table-tools"><div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search invoices or customers..."/></div><span className="results-count">{filteredInvoices.length} invoices</span></div><InvoiceTable invoices={filteredInvoices} customerMap={customerMap} changeStatus={changeStatus} loading={loading}/></div>}
      {tab==="customers"&&<div className="section-card"><div className="table-tools"><div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search customers..."/></div><span className="results-count">{filteredCustomers.length} customers</span></div>{loading?<Loading/>:filteredCustomers.length?<div className="customer-grid">{filteredCustomers.map(c=><div className="customer-card" key={c.id}><div className="avatar large">{c.name[0]?.toUpperCase()}</div><h3>{c.name}</h3><p>{c.email||"No email provided"}</p><div className="customer-card-foot"><span>{invoices.filter(i=>i.customer_id===c.id).length} invoices</span><b>{money(invoices.filter(i=>i.customer_id===c.id).reduce((s,i)=>s+Number(i.amount),0))}</b></div></div>)}</div>:<Empty title="No customers found" detail="Add a customer or change your search."/>}</div>}
      <footer className="footer">PaidPilot <span>•</span> A clearer path to getting paid.</footer>
      </div>
    </main>
    {modal&&<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(null);}}><section className="modal"><div className="modal-head"><div><span className="eyebrow">{modal==="customer"?"CUSTOMER RECORD":"BILLING RECORD"}</span><h2>{modal==="customer"?"Add a customer":"Create an invoice"}</h2></div><button className="icon-button" onClick={()=>setModal(null)} aria-label="Close"><X/></button></div>
      <form className="form modal-form" onSubmit={modal==="customer"?addCustomer:addInvoice}>
      {modal==="customer"?<><label>Customer or company name<input required value={customerName} onChange={e=>setCustomerName(e.target.value)} placeholder="e.g. Northstar Studio"/></label><label>Email address <span className="optional">optional</span><input type="email" value={customerEmail} onChange={e=>setCustomerEmail(e.target.value)} placeholder="billing@customer.com"/></label></>:<>
        <label>Customer<select required value={invoiceCustomer} onChange={e=>setInvoiceCustomer(e.target.value)}><option value="">Choose a customer</option>{customers.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label>
        <div className="form-row"><label>Invoice number<input required value={invoiceNumber} onChange={e=>setInvoiceNumber(e.target.value)} placeholder="INV-001"/></label><label>Amount (CAD)<input required type="number" min="0" step="0.01" value={invoiceAmount} onChange={e=>setInvoiceAmount(e.target.value)} placeholder="250.00"/></label></div>
        <label>Description <span className="optional">optional</span><input value={invoiceDescription} onChange={e=>setInvoiceDescription(e.target.value)} placeholder="Services provided"/></label>
        <div className="form-row"><label>Due date<input type="date" value={invoiceDue} onChange={e=>setInvoiceDue(e.target.value)}/></label><label>Status<select value={invoiceStatus} onChange={e=>setInvoiceStatus(e.target.value as Invoice["status"])}><option value="draft">Draft</option><option value="sent">Sent</option><option value="paid">Paid</option><option value="overdue">Overdue</option></select></label></div>
      </>}
      {error&&<p className="notice error">{error}</p>}<div className="modal-actions"><button type="button" className="secondary" onClick={()=>setModal(null)}>Cancel</button><button className="primary" disabled={busy}>{busy?<LoaderCircle className="spin" size={17}/>:<><Plus size={17}/> Save {modal==="customer"?"customer":"invoice"}</>}</button></div></form>
    </section></div>}
  </div>;
}

function Loading(){return <div className="loading"><LoaderCircle className="spin"/> Loading your records…</div>}
function Empty({title,detail}:{title:string;detail:string}){return <div className="empty"><div className="empty-icon"><FileText size={22}/></div><b>{title}</b><p>{detail}</p></div>}
function InvoiceTable({invoices,customerMap,changeStatus,loading}:{invoices:Invoice[];customerMap:Map<string,Customer>;changeStatus:(i:Invoice,s:Invoice["status"])=>void;loading:boolean}){
  if(loading)return <Loading />;
  if(!invoices.length)return <Empty title="Nothing here just yet" detail="Create an invoice and it will appear here." />;
  const statusIcon=(s:string)=>s==="paid"?<CheckCircle2 size={14}/>:s==="overdue"?<AlertCircle size={14}/>:s==="sent"?<Clock3 size={14}/>:<FileText size={14}/>;
  return <div className="table-wrap"><table><thead><tr><th>Invoice</th><th>Customer</th><th>Due date</th><th>Amount</th><th>Status</th><th>Update status</th></tr></thead><tbody>{invoices.map(i=><tr key={i.id}><td><b>{i.invoice_number}</b><span className="cell-sub">{i.description||"No description"}</span></td><td>{customerMap.get(i.customer_id)?.name||"Customer"}</td><td>{prettyDate(i.due_date)}</td><td className="amount">{money(Number(i.amount))}</td><td><span className={`badge ${i.status}`}>{statusIcon(i.status)}{i.status}</span></td><td><select aria-label={`Update ${i.invoice_number} status`} className="status-select" value={i.status} onChange={e=>changeStatus(i,e.target.value as Invoice["status"])}>{["draft","sent","paid","overdue"].map(s=><option value={s} key={s}>{s[0].toUpperCase()+s.slice(1)}</option>)}</select></td></tr>)}</tbody></table></div>;
}

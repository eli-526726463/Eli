import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PaidPilot — Get paid with confidence",
  description: "Simple invoice and customer tracking for small businesses."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}

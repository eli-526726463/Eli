"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Plane, ArrowRight, LoaderCircle } from "lucide-react";

export default function AuthForm() {
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const supabase = createClient();
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (!data.session) {
          setMessage("Check your email to confirm your account, then sign in.");
        } else { router.push("/dashboard"); router.refresh(); }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push("/dashboard"); router.refresh();
      }
    } catch (err) { setMessage(err instanceof Error ? err.message : "Something went wrong."); }
    finally { setBusy(false); }
  }

  return <main className="auth-shell">
    <div className="auth-left">
      <a className="brand" href="/"><span className="brand-mark"><Plane size={19}/></span> paidpilot</a>
      <div className="auth-copy"><span className="eyebrow">LESS CHASING. MORE GROWING.</span><h1>Get paid with<br/><em>confidence.</em></h1><p>Keep customers, invoices, and payment status in one calm, clear workspace.</p>
        <div className="quote-card"><div className="quote-stars">★★★★★</div><p>“Finally, I can see what’s outstanding without digging through emails.”</p><span>— A small business owner (sample quote)</span></div>
      </div>
      <div className="auth-foot">Built for the people who keep business moving.</div>
    </div>
    <section className="auth-right"><div className="auth-form-wrap">
      <div className="mobile-brand"><a className="brand" href="/"><span className="brand-mark"><Plane size={19}/></span> paidpilot</a></div>
      <span className="eyebrow">{mode === "signup" ? "YOUR WORKSPACE STARTS HERE" : "WELCOME BACK"}</span>
      <h2>{mode === "signup" ? "Create your account" : "Sign in to PaidPilot"}</h2>
      <p className="muted">Use your email and a strong password to get started.</p>
      <form onSubmit={submit} className="form">
        <label>Email address<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@business.com"/></label>
        <label>Password<input type="password" minLength={8} autoComplete={mode === "signup" ? "new-password" : "current-password"} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/></label>
        <button className="primary full" disabled={busy}>{busy ? <LoaderCircle className="spin" size={18}/> : <>{mode === "signup" ? "Create account" : "Sign in"} <ArrowRight size={17}/></>}</button>
      </form>
      {message && <p className="notice" role="status">{message}</p>}
      <p className="switch">{mode === "signup" ? "Already have an account?" : "New to PaidPilot?"} <button onClick={()=>{setMode(mode==="signup"?"signin":"signup");setMessage("");}}>{mode === "signup" ? "Sign in" : "Create account"}</button></p>
      <p className="legal">By continuing, you agree to use PaidPilot responsibly. Add real customer data only after setup and security checks are complete.</p>
    </div></section>
  </main>;
}

-- PaidPilot base schema with tenant-scoped row-level security.
-- Safe to run in a new Supabase project. If you already created the two
-- starter tables, use the separate upgrade notes in README.md first.

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(trim(name)) > 0),
  email text,
  created_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete restrict,
  invoice_number text not null,
  description text,
  amount numeric(12,2) not null check (amount >= 0),
  due_date date,
  status text not null default 'draft'
    check (status in ('draft', 'sent', 'paid', 'overdue')),
  created_at timestamptz not null default now(),
  unique (user_id, invoice_number)
);

create index if not exists customers_user_id_idx on public.customers(user_id);
create index if not exists invoices_user_id_idx on public.invoices(user_id);
create index if not exists invoices_customer_id_idx on public.invoices(customer_id);
create index if not exists invoices_status_due_date_idx on public.invoices(status, due_date);

alter table public.customers enable row level security;
alter table public.invoices enable row level security;

drop policy if exists "Users manage their own customers" on public.customers;
create policy "Users manage their own customers"
on public.customers for all to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users manage their own invoices" on public.invoices;
create policy "Users manage their own invoices"
on public.invoices for all to authenticated
using (
  auth.uid() = user_id
  and exists (
    select 1 from public.customers c
    where c.id = customer_id and c.user_id = auth.uid()
  )
)
with check (
  auth.uid() = user_id
  and exists (
    select 1 from public.customers c
    where c.id = customer_id and c.user_id = auth.uid()
  )
);

-- NOTE: If you already ran the initial starter SQL in the Supabase dashboard,
-- don't rerun this file blindly. The app's current schema matches the starter
-- schema. The policy replacement above adds a stronger customer ownership check.
